class Item < ApplicationRecord
	belongs_to :admin
end
